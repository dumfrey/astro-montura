package com.astro.montura

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Iconos dibujados en un solo color (rojo, para no perder la visión nocturna). */
class IconoCategoria(private val categoria: String, private val color: Int, private val tam: Int) : Drawable() {

    private val trazo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        this.color = this@IconoCategoria.color
    }
    private val relleno = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        this.color = this@IconoCategoria.color
    }

    override fun getIntrinsicWidth(): Int = tam
    override fun getIntrinsicHeight(): Int = tam

    override fun draw(c: Canvas) {
        val b = bounds
        val s = minOf(b.width(), b.height()).toFloat()
        c.save()
        c.translate(b.left + (b.width() - s) / 2f, b.top + (b.height() - s) / 2f)
        c.scale(s / 100f, s / 100f)
        trazo.strokeWidth = 6f
        when (categoria) {
            Astro.SISTEMA_SOLAR -> sistemaSolar(c)
            Astro.GALAXIAS -> galaxia(c)
            Astro.NEBULOSAS -> nebulosa(c)
            else -> espacioProfundo(c)
        }
        c.restore()
    }

    /** Planeta con anillo (tipo Saturno). */
    private fun sistemaSolar(c: Canvas) {
        c.drawCircle(50f, 50f, 22f, relleno)
        c.save()
        c.rotate(-22f, 50f, 50f)
        val anillo = RectF(8f, 38f, 92f, 62f)
        trazo.color = 0xFF330000.toInt()
        trazo.strokeWidth = 12f
        c.drawOval(anillo, trazo)
        trazo.color = color
        trazo.strokeWidth = 6f
        c.drawOval(anillo, trazo)
        c.restore()
        c.drawCircle(50f, 50f, 22f, relleno)
        // la parte frontal del anillo
        c.save()
        c.rotate(-22f, 50f, 50f)
        val arco = Path()
        arco.addArc(RectF(8f, 38f, 92f, 62f), 10f, 160f)
        trazo.color = 0xFF330000.toInt()
        trazo.strokeWidth = 12f
        c.drawPath(arco, trazo)
        trazo.color = color
        trazo.strokeWidth = 6f
        c.drawPath(arco, trazo)
        c.restore()
    }

    /** Espiral con núcleo. */
    private fun galaxia(c: Canvas) {
        c.drawCircle(50f, 50f, 8f, relleno)
        for (brazo in 0..1) {
            val p = Path()
            val desfase = brazo * PI
            var t = 0.0
            var primero = true
            while (t <= 3.6) {
                val r = 8.0 + t * 11.0
                val a = t + desfase
                val x = (50 + r * cos(a)).toFloat()
                val y = (50 + r * sin(a)).toFloat()
                if (primero) { p.moveTo(x, y); primero = false } else p.lineTo(x, y)
                t += 0.1
            }
            c.drawPath(p, trazo)
        }
    }

    /** Nube de gas: círculos que se mezclan. */
    private fun nebulosa(c: Canvas) {
        val nube = Path()
        nube.addCircle(34f, 58f, 20f, Path.Direction.CW)
        nube.addCircle(56f, 42f, 24f, Path.Direction.CW)
        nube.addCircle(70f, 62f, 18f, Path.Direction.CW)
        nube.addRoundRect(RectF(30f, 55f, 78f, 80f), 12f, 12f, Path.Direction.CW)
        relleno.alpha = 90
        c.drawPath(nube, relleno)
        relleno.alpha = 255
        c.drawCircle(50f, 52f, 4f, relleno)
        c.drawCircle(64f, 40f, 3f, relleno)
        c.drawCircle(38f, 62f, 3f, relleno)
    }

    /** Estrellas de cuatro puntas sobre el cielo profundo. */
    private fun espacioProfundo(c: Canvas) {
        estrella(c, 50f, 48f, 26f)
        estrella(c, 20f, 22f, 11f)
        estrella(c, 80f, 24f, 9f)
        estrella(c, 78f, 78f, 12f)
        estrella(c, 22f, 76f, 8f)
    }

    private fun estrella(c: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Path()
        val i = r * 0.25f
        p.moveTo(cx, cy - r)
        p.lineTo(cx + i, cy - i)
        p.lineTo(cx + r, cy)
        p.lineTo(cx + i, cy + i)
        p.lineTo(cx, cy + r)
        p.lineTo(cx - i, cy + i)
        p.lineTo(cx - r, cy)
        p.lineTo(cx - i, cy - i)
        p.close()
        c.drawPath(p, relleno)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
