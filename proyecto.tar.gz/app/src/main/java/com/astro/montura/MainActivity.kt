package com.astro.montura

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    companion object {
        const val ROJO = 0xFFFF2A2A.toInt()
        const val ROJO_OSCURO = 0xFF330000.toInt()
        const val VERDE = 0xFF33FF66.toInt()
        const val GRIS = 0xFF8A8A8A.toInt()
        const val NEGRO = Color.BLACK
        const val ALTURA_MINIMA = 15.0
        val VEL_GOTO = listOf("0.25", "0.5", "1", "2", "3")
        val VEL_MANUAL = listOf("0.05", "0.1", "0.25", "0.5", "1", "2", "3")
    }

    private val ui = Handler(Looper.getMainLooper())
    private val montura = Montura { msg -> ui.post { log(msg) } }
    private val trabajo = Executors.newSingleThreadExecutor()
    private val manual = Executors.newSingleThreadExecutor()
    private val telemetria = Executors.newSingleThreadExecutor()
    private val ocupado = AtomicBoolean(false)
    private val detenerSeguimiento = AtomicBoolean(false)
    private val leyendo = AtomicBoolean(false)

    private lateinit var etIp: EditText
    private lateinit var etLat: EditText
    private lateinit var etLon: EditText
    private lateinit var tvEstado: TextView
    private lateinit var tvPosicion: TextView
    private lateinit var btnConectar: Button
    private val tvsSeleccion = ArrayList<TextView>()
    private val btnsSeguir = ArrayList<Button>()
    private val spGotos = ArrayList<Spinner>()
    private val spManuals = ArrayList<Spinner>()
    private val paneles = HashMap<String, LinearLayout>()
    private val cabeceras = HashMap<String, Button>()
    private var categoriaAbierta: String? = null
    @Volatile private var conectando = false
    private lateinit var tvLog: TextView
    private val filas = HashMap<Int, TextView>()
    private var seleccion = -1
    private val lineasLog = ArrayList<String>()

    private val colador: java.text.Collator = java.text.Collator.getInstance(Locale("es")).apply {
        strength = java.text.Collator.PRIMARY
    }

    /** Orden alfabético en español; los números se comparan como números (M8 antes que M17). */
    private fun compararNatural(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val ta = re.findAll(a).map { it.value }.toList()
        val tb = re.findAll(b).map { it.value }.toList()
        for (k in 0 until minOf(ta.size, tb.size)) {
            val x = ta[k]
            val y = tb[k]
            val c = if (x[0].isDigit() && y[0].isDigit()) {
                x.toLong().compareTo(y.toLong())
            } else {
                colador.compare(x, y)
            }
            if (c != 0) return c
        }
        return ta.size - tb.size
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ UI
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = getSharedPreferences("ajustes", MODE_PRIVATE)

        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(NEGRO)

        val scroll = ScrollView(this)
        val cont = LinearLayout(this)
        cont.orientation = LinearLayout.VERTICAL
        cont.setPadding(dp(12), dp(12), dp(12), dp(12))
        scroll.addView(cont)
        raiz.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val titulo = texto("ASTRO MONTURA  AZ-GTi", 20f, true)
        cont.addView(titulo)
        tvEstado = texto("Desconectado", 14f, false)
        cont.addView(tvEstado)
        tvPosicion = texto("Montura: --", 14f, false)
        cont.addView(tvPosicion)

        cont.addView(texto("IP de la montura", 12f, false))
        etIp = campo(prefs.getString("ip", IP_POR_DEFECTO) ?: IP_POR_DEFECTO, false)
        cont.addView(etIp)
        cont.addView(texto("Latitud (N +) y Longitud (E +)", 12f, false))
        val filaCoord = LinearLayout(this)
        filaCoord.orientation = LinearLayout.HORIZONTAL
        etLat = campo(prefs.getString("lat", "8.99") ?: "8.99", true)
        etLon = campo(prefs.getString("lon", "-79.56") ?: "-79.56", true)
        filaCoord.addView(etLat, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        filaCoord.addView(etLon, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cont.addView(filaCoord)

        btnConectar = boton("CONECTAR") { conectar() }
        cont.addView(btnConectar)
        cont.addView(texto("Objetos por categoría (gris = no visible)", 12f, false))

        for (cat in Astro.CATEGORIAS) {
            val cab = Button(this)
            cab.setTextColor(ROJO)
            cab.setBackgroundColor(ROJO_OSCURO)
            cab.textSize = 16f
            cab.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            cab.setPadding(dp(14), 0, dp(14), 0)
            cab.compoundDrawablePadding = dp(14)
            cab.setCompoundDrawablesWithIntrinsicBounds(IconoCategoria(cat, ROJO, dp(34)), null, null, null)
            val lpCab = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
            lpCab.topMargin = dp(8)
            cab.layoutParams = lpCab
            cab.setOnClickListener { abrirCategoria(cat) }
            cabeceras[cat] = cab
            cont.addView(cab)

            val panel = LinearLayout(this)
            panel.orientation = LinearLayout.VERTICAL
            panel.setPadding(dp(4), dp(6), dp(4), dp(6))
            panel.visibility = View.GONE
            paneles[cat] = panel
            cont.addView(panel)

            val delaCategoria = Astro.CATALOGO.withIndex().filter { it.value.categoria == cat }
                .sortedWith(Comparator { a, b -> compararNatural(a.value.nombre, b.value.nombre) })
            for ((i, o) in delaCategoria) {
                val tv = texto(o.nombre, 15f, false)
                tv.setPadding(dp(8), dp(9), dp(8), dp(9))
                tv.setOnClickListener { elegir(i) }
                filas[i] = tv
                panel.addView(tv)
            }
            val sel = texto("Elige un objeto", 14f, true)
            sel.setPadding(0, dp(8), 0, dp(8))
            tvsSeleccion.add(sel)
            panel.addView(sel)
            crearControles(panel)
        }
        actualizarCabeceras()

        val cbAz = CheckBox(this)
        cbAz.text = "Invertir azimut"
        cbAz.setTextColor(ROJO)
        cbAz.isChecked = prefs.getBoolean("inv_az", false)
        montura.signo[1] = if (cbAz.isChecked) -1 else 1
        cbAz.setOnCheckedChangeListener { _, marcado ->
            montura.signo[1] = if (marcado) -1 else 1
            montura.calibrado = false
            prefs.edit().putBoolean("inv_az", marcado).apply()
            log("Azimut invertido: $marcado. Hay que calibrar de nuevo.")
        }
        val cbAlt = CheckBox(this)
        cbAlt.text = "Invertir altitud"
        cbAlt.setTextColor(ROJO)
        cbAlt.isChecked = prefs.getBoolean("inv_alt", false)
        montura.signo[2] = if (cbAlt.isChecked) -1 else 1
        cbAlt.setOnCheckedChangeListener { _, marcado ->
            montura.signo[2] = if (marcado) -1 else 1
            montura.calibrado = false
            prefs.edit().putBoolean("inv_alt", marcado).apply()
            log("Altitud invertida: $marcado. Hay que calibrar de nuevo.")
        }
        cont.addView(cbAz)
        cont.addView(cbAlt)

        tvLog = texto("", 12f, false)
        tvLog.typeface = Typeface.MONOSPACE
        cont.addView(tvLog)

        val parar = Button(this)
        parar.text = "■ PARAR TODO"
        parar.textSize = 20f
        parar.setTextColor(Color.WHITE)
        parar.setBackgroundColor(0xFFAA0000.toInt())
        parar.setOnClickListener { pararTodo() }
        raiz.addView(parar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))

        setContentView(raiz)
        log("Listo. Conecta el celular al WiFi 'SynScan_xxxx' y pulsa CONECTAR.")
        refrescar()
    }

    private fun columnas(a: View, b: View, margenArriba: Int = 6): LinearLayout {
        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        val la = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        la.setMargins(0, dp(margenArriba), dp(4), 0)
        val lb = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lb.setMargins(dp(4), dp(margenArriba), 0, 0)
        fila.addView(a, la)
        fila.addView(b, lb)
        return fila
    }

    private fun columnaVel(titulo: String, sp: Spinner): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(texto(titulo, 12f, false))
        c.addView(sp)
        return c
    }

    /** Los 4 pasos (2 columnas), los mandos manuales y, al final, las velocidades. */
    private fun crearControles(p: LinearLayout) {
        val bs = boton("3. SEGUIR") { seguir() }
        btnsSeguir.add(bs)
        p.addView(columnas(boton("1. CALIBRAR") { calibrar() }, boton("2. APUNTAR") { apuntar() }))
        p.addView(columnas(bs, boton("4. SINCRONIZAR") { sincronizar() }, 8))

        val tit = texto("Mandos manuales: mantén pulsada la flecha", 12f, false)
        tit.setPadding(0, dp(12), 0, 0)
        p.addView(tit)
        val fila1 = LinearLayout(this)
        fila1.gravity = Gravity.CENTER
        fila1.addView(flecha("▲ Arriba", 2, 1.0))
        p.addView(fila1)
        val fila2 = LinearLayout(this)
        fila2.gravity = Gravity.CENTER
        fila2.addView(flecha("◀ Izq", 1, -1.0))
        fila2.addView(flecha("Der ▶", 1, 1.0))
        p.addView(fila2)
        val fila3 = LinearLayout(this)
        fila3.gravity = Gravity.CENTER
        fila3.addView(flecha("▼ Abajo", 2, -1.0))
        p.addView(fila3)

        val sg = spinner(VEL_GOTO, 1, spGotos)
        spGotos.add(sg)
        val sm = spinner(VEL_MANUAL, 3, spManuals)
        spManuals.add(sm)
        val vel = columnas(columnaVel("Vel. APUNTAR (°/s)", sg), columnaVel("Vel. MANUAL (°/s)", sm), 12)
        p.addView(vel)
    }

    private fun abrirCategoria(cat: String) {
        categoriaAbierta = if (categoriaAbierta == cat) null else cat
        val o = objetoElegido()
        if (o != null && o.categoria != categoriaAbierta) seleccion = -1
        actualizarCabeceras()
        refrescar()
    }

    private fun actualizarCabeceras() {
        for (cat in Astro.CATEGORIAS) {
            val abierta = cat == categoriaAbierta
            val n = Astro.CATALOGO.count { it.categoria == cat }
            cabeceras[cat]?.text = (if (abierta) "▲ " else "▼ ") + cat + " ($n)"
            paneles[cat]?.visibility = if (abierta) View.VISIBLE else View.GONE
        }
    }

    private fun velGoto(): Double = (spGotos[0].selectedItem as String).toDouble()
    private fun velManual(): Double = (spManuals[0].selectedItem as String).toDouble()
    private fun textoSeguir(t: String) { for (b in btnsSeguir) b.text = t }

    private fun texto(t: String, tam: Float, negrita: Boolean): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = tam
        tv.setTextColor(ROJO)
        if (negrita) tv.setTypeface(null, Typeface.BOLD)
        return tv
    }

    private fun campo(valor: String, numerico: Boolean): EditText {
        val et = EditText(this)
        et.setText(valor)
        et.setTextColor(ROJO)
        et.setHintTextColor(GRIS)
        et.setSingleLine(true)
        if (numerico) {
            et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or
                InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        return et
    }

    private fun boton(t: String, accion: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setTextColor(ROJO)
        b.setBackgroundColor(ROJO_OSCURO)
        b.setOnClickListener { accion() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        b.layoutParams = lp
        return b
    }

    private fun spinner(valores: List<String>, inicial: Int, grupo: List<Spinner>): Spinner {
        val sp = Spinner(this)
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, valores) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(ROJO)
                return v
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent) as TextView
                v.setTextColor(ROJO)
                v.setBackgroundColor(NEGRO)
                v.setPadding(dp(12), dp(12), dp(12), dp(12))
                return v
            }
        }
        sp.adapter = ad
        sp.setSelection(inicial)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                for (o in grupo) if (o !== sp && o.selectedItemPosition != pos) o.setSelection(pos)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    /** Flecha de mantener pulsada: mueve el eje mientras el dedo esté encima. */
    private fun flecha(t: String, eje: Int, signoDir: Double): Button {
        val b = Button(this)
        b.text = t
        b.setTextColor(ROJO)
        b.setBackgroundColor(ROJO_OSCURO)
        b.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    if (!montura.conectado) {
                        log("No conectado.")
                    } else if (ocupado.get()) {
                        log("Hay una operación en curso. Pulsa PARAR TODO primero.")
                    } else {
                        val vel = velManual() * signoDir
                        manual.execute {
                            try { montura.setVel(eje, vel) } catch (e: Exception) { ui.post { log("Error: ${e.message}") } }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    if (montura.conectado && !ocupado.get()) {
                        manual.execute {
                            try { montura.setVel(eje, 0.0) } catch (e: Exception) { ui.post { log("Error: ${e.message}") } }
                        }
                    }
                    true
                }
                else -> true
            }
        }
        val lp = LinearLayout.LayoutParams(dp(130), dp(60))
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        b.layoutParams = lp
        return b
    }

    // --------------------------------------------------------- utilidades
    private fun log(msg: String) {
        val h = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        lineasLog.add("$h $msg")
        while (lineasLog.size > 40) lineasLog.removeAt(0)
        tvLog.text = lineasLog.joinToString("\n")
    }

    private fun latLon(): Pair<Double, Double> {
        val lat = etLat.text.toString().toDoubleOrNull() ?: 8.99
        val lon = etLon.text.toString().toDoubleOrNull() ?: -79.56
        return Pair(lat, lon)
    }

    private fun guardarAjustes() {
        getSharedPreferences("ajustes", MODE_PRIVATE).edit()
            .putString("ip", etIp.text.toString().trim())
            .putString("lat", etLat.text.toString().trim())
            .putString("lon", etLon.text.toString().trim())
            .apply()
    }

    @Suppress("DEPRECATION")
    private fun redWifi(): Network? {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n
        }
        return null
    }

    private fun objetoElegido(): Objeto? = if (seleccion in Astro.CATALOGO.indices) Astro.CATALOGO[seleccion] else null

    private fun posicionDe(o: Objeto, dtSeg: Double = 0.0): AltAz {
        val (lat, lon) = latLon()
        return Astro.posicion(o, System.currentTimeMillis() + (dtSeg * 1000).toLong(), lat, lon)
    }

    private fun elegir(i: Int) {
        val o = Astro.CATALOGO[i]
        val p = posicionDe(o)
        if (p.altitud < ALTURA_MINIMA) {
            log("${o.nombre} no es visible ahora (altitud ${fmt(p.altitud)}°).")
            return
        }
        seleccion = i
        refrescar()
    }

    private fun fmt(x: Double): String = String.format(Locale.US, "%.1f", x)

    private fun refrescar() {
        for ((i, o) in Astro.CATALOGO.withIndex()) {
            val p = posicionDe(o)
            val visible = p.altitud >= ALTURA_MINIMA
            val tv = filas[i] ?: continue
            tv.text = String.format(
                Locale.US, "%s   alt %s°  az %s° %s", o.nombre, fmt(p.altitud), fmt(p.azimut), Astro.punto(p.azimut)
            )
            tv.setTextColor(if (visible) ROJO else GRIS)
            tv.setBackgroundColor(if (i == seleccion) ROJO_OSCURO else NEGRO)
            if (i == seleccion && !visible) seleccion = -1
        }
        val o = objetoElegido()
        val textoSel = if (o == null) {
            "Elige un objeto visible"
        } else {
            val p = posicionDe(o)
            "Elegido: ${o.nombre}  (alt ${fmt(p.altitud)}°, az ${fmt(p.azimut)}°)"
        }
        for (t in tvsSeleccion) t.text = textoSel
        when {
            conectando -> {
                btnConectar.text = "CONECTANDO..."
                btnConectar.setTextColor(ROJO)
                btnConectar.setBackgroundColor(ROJO_OSCURO)
            }
            montura.conectado -> {
                btnConectar.text = "CONECTADO"
                btnConectar.setTextColor(VERDE)
                btnConectar.setBackgroundColor(ROJO_OSCURO)
            }
            else -> {
                btnConectar.text = "CONECTAR"
                btnConectar.setTextColor(ROJO)
                btnConectar.setBackgroundColor(ROJO_OSCURO)
            }
        }
        tvEstado.text = when {
            !montura.conectado -> "Desconectado"
            !montura.calibrado -> "Conectado - falta calibrar"
            else -> "Conectado y calibrado"
        }
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
    }

    private val tick = Runnable {
        refrescar()
        leerTelemetria()
    }

    private fun leerTelemetria() {
        if (!montura.conectado || !leyendo.compareAndSet(false, true)) return
        telemetria.execute {
            try {
                val (az, alt) = montura.azimutAltitud()
                ui.post {
                    tvPosicion.text = if (montura.calibrado) "Montura: az ${fmt(az)}°  alt ${fmt(alt)}°" else "Montura: sin calibrar"
                }
            } catch (_: Exception) {
            } finally {
                leyendo.set(false)
            }
        }
    }

    private fun confirmar(titulo: String, mensaje: String, si: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(mensaje)
            .setPositiveButton("Sí") { _, _ -> si() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Ejecuta una tarea larga en segundo plano evitando que haya dos a la vez. */
    private fun tarea(descripcion: String, accion: () -> Unit) {
        if (!ocupado.compareAndSet(false, true)) {
            log("Hay otra operación en curso. Pulsa PARAR TODO si quieres cancelarla.")
            return
        }
        trabajo.execute {
            try {
                accion()
            } catch (e: Exception) {
                ui.post { log("$descripcion: ${e.message}") }
            } finally {
                ocupado.set(false)
            }
        }
    }

    // ------------------------------------------------------------ acciones
    private fun conectar() {
        guardarAjustes()
        val ip = etIp.text.toString().trim()
        val red = redWifi()
        log(if (red == null) "Aviso: no veo una red WiFi activa." else "Conectando con $ip por WiFi...")
        tarea("Conexión") {
            conectando = true
            ui.post { refrescar() }
            try {
                montura.conectar(ip, red)
                ui.post { log("Conectada. Ahora calibra: tubo nivelado y mirando al Norte.") }
            } finally {
                conectando = false
                ui.post { refrescar() }
            }
        }
    }

    private fun calibrar() {
        if (!montura.conectado) { log("Primero conecta."); return }
        confirmar(
            "Calibrar",
            "¿El tubo está NIVELADO (horizontal) y apuntando al NORTE? Esa posición se tomará como azimut 0°, altitud 0°."
        ) {
            tarea("Calibrar") {
                montura.calibrarEn(0.0, 0.0)
                ui.post { log("Calibrada en az 0°, alt 0°."); refrescar() }
            }
        }
    }

    private fun sincronizar() {
        val o = objetoElegido()
        if (!montura.conectado) { log("Primero conecta."); return }
        if (o == null) { log("Elige un objeto."); return }
        confirmar("Sincronizar", "¿${o.nombre} está CENTRADO en el ocular? La montura tomará su posición actual como la del objeto.") {
            tarea("Sincronizar") {
                val p = posicionDe(o)
                montura.calibrarEn(p.azimut, p.altitud)
                ui.post { log("Sincronizada con ${o.nombre}."); refrescar() }
            }
        }
    }

    private fun apuntar() {
        val o = objetoElegido()
        if (!montura.conectado) { log("Primero conecta."); return }
        if (!montura.calibrado) { log("Primero calibra."); return }
        if (o == null) { log("Elige un objeto visible."); return }
        val vel = velGoto()
        val p0 = posicionDe(o)
        confirmar("Apuntar", "La montura girará hacia ${o.nombre} (az ${fmt(p0.azimut)}°, alt ${fmt(p0.altitud)}°). Asegúrate de que nada estorbe el giro.") {
            tarea("Apuntar") {
                ui.post { log("Apuntando a ${o.nombre} a $vel °/s...") }
                val p = posicionDe(o)
                val llego = montura.irA(p.azimut, p.altitud, vel)
                ui.post { log(if (llego) "Llegó a ${o.nombre}." else "Movimiento detenido.") }
            }
        }
    }

    private fun seguir() {
        if (ocupado.get() && !detenerSeguimiento.get()) {
            // Ya hay seguimiento (u otra operación): este botón lo detiene
            detenerSeguimiento.set(true)
            log("Deteniendo seguimiento...")
            return
        }
        val o = objetoElegido()
        if (!montura.conectado) { log("Primero conecta."); return }
        if (!montura.calibrado) { log("Primero calibra."); return }
        if (o == null) { log("Elige un objeto visible."); return }
        val vel = velGoto()
        tarea("Seguimiento") {
            detenerSeguimiento.set(false)
            ui.post { textoSeguir("3. DETENER"); log("Apuntando a ${o.nombre} antes de seguir...") }
            try {
                val p = posicionDe(o)
                val llego = montura.irA(p.azimut, p.altitud, vel)
                if (llego && !detenerSeguimiento.get()) {
                    ui.post { log("Siguiendo a ${o.nombre}.") }
                    montura.seguir({ dt -> val q = posicionDe(o, dt); Pair(q.azimut, q.altitud) }, detenerSeguimiento)
                    ui.post { log("Seguimiento terminado.") }
                } else {
                    ui.post { log("Seguimiento cancelado.") }
                }
            } finally {
                ui.post { textoSeguir("3. SEGUIR") }
            }
        }
    }

    private fun pararTodo() {
        detenerSeguimiento.set(true)
        Thread {
            try { montura.parar() } catch (_: Exception) {}
            ui.post { log("PARADA: motores detenidos.") }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
        detenerSeguimiento.set(true)
        Thread { try { montura.desconectar() } catch (_: Exception) {} }.start()
        trabajo.shutdown()
        manual.shutdown()
        telemetria.shutdown()
    }
}
