package com.astro.montura

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Un objeto del catálogo. Si [fijo] es true, [raHoras]/[decGrados] son coordenadas J2000. */
data class Objeto(
    val nombre: String,
    val raHoras: Double = 0.0,
    val decGrados: Double = 0.0,
    val fijo: Boolean = false,
    val categoria: String = ""
)

/** Altitud y azimut en grados (azimut desde el Norte hacia el Este). */
data class AltAz(val altitud: Double, val azimut: Double)

/**
 * Cálculo de posiciones. Luna y planetas: elementos orbitales de baja precisión
 * (validados contra JPL Horizons con error menor a 0.06 grados). Estrellas y
 * objetos de cielo profundo: coordenadas J2000 con corrección de precesión.
 */
object Astro {
    private const val D2R = PI / 180.0

    private fun rev(x: Double): Double = x - 360.0 * floor(x / 360.0)
    private fun sind(x: Double): Double = sin(x * D2R)
    private fun cosd(x: Double): Double = cos(x * D2R)
    private fun tand(x: Double): Double = tan(x * D2R)
    private fun atan2d(y: Double, x: Double): Double = atan2(y, x) / D2R
    private fun asind(x: Double): Double = asin(x) / D2R

    const val SISTEMA_SOLAR = "Sistema Solar"
    const val GALAXIAS = "Galaxias"
    const val NEBULOSAS = "Nebulosas"
    const val ESPACIO_PROFUNDO = "Espacio profundo"
    val CATEGORIAS = listOf(SISTEMA_SOLAR, GALAXIAS, NEBULOSAS, ESPACIO_PROFUNDO)

    private fun ss(n: String) = Objeto(n, categoria = SISTEMA_SOLAR)
    private fun gx(n: String, ra: Double, de: Double) = Objeto(n, ra, de, true, GALAXIAS)
    private fun nb(n: String, ra: Double, de: Double) = Objeto(n, ra, de, true, NEBULOSAS)
    private fun ep(n: String, ra: Double, de: Double) = Objeto(n, ra, de, true, ESPACIO_PROFUNDO)

    val CATALOGO: List<Objeto> = listOf(
        ss("Luna"), ss("Mercurio"), ss("Venus"), ss("Marte"),
        ss("Júpiter"), ss("Saturno"), ss("Urano"), ss("Neptuno"),
        gx("M31 Galaxia de Andrómeda", 0.7123, 41.269),
        gx("M33 Galaxia del Triángulo", 1.5642, 30.660),
        gx("M81 Galaxia de Bode", 9.9258, 69.065),
        gx("M51 Galaxia del Remolino", 13.4981, 47.195),
        gx("NGC 253 Galaxia del Escultor", 0.7925, -25.288),
        gx("Gran Nube de Magallanes", 5.3917, -69.750),
        gx("Pequeña Nube de Magallanes", 0.8783, -72.800),
        nb("M42 Nebulosa de Orión", 5.5881, -5.391),
        nb("M8 Nebulosa de la Laguna", 18.0633, -24.387),
        nb("M20 Nebulosa Trífida", 18.0400, -23.030),
        nb("M17 Nebulosa Omega", 18.3464, -16.170),
        nb("M57 Nebulosa del Anillo", 18.8932, 33.029),
        nb("M27 Nebulosa Dumbbell", 19.9936, 22.721),
        nb("M1 Nebulosa del Cangrejo", 5.5756, 22.017),
        nb("NGC 3372 Nebulosa de Carina", 10.7500, -59.870),
        ep("M45 Pléyades", 3.7900, 24.117),
        ep("M13 Cúmulo de Hércules", 16.6949, 36.460),
        ep("M22 Cúmulo globular", 18.6070, -23.905),
        ep("M7 Cúmulo de Ptolomeo", 17.8980, -34.793),
        ep("Omega Centauri (NGC 5139)", 13.4473, -47.480),
        ep("Sirio", 6.7525, -16.716),
        ep("Canopus", 6.3992, -52.696),
        ep("Arturo", 14.2610, 19.182),
        ep("Vega", 18.6156, 38.784),
        ep("Antares", 16.4901, -26.432),
        ep("Rigel", 5.2423, -8.202),
        ep("Betelgeuse", 5.9195, 7.407),
        ep("Altair", 19.8464, 8.868),
        ep("Fomalhaut", 22.9608, -29.622),
        ep("Acrux", 12.4433, -63.099)
    )

    // N0,N1, i0,i1, w0,w1, a0,a1, e0,e1, M0,M1  (valor = v0 + v1 * d)
    private val ELEM: Map<String, DoubleArray> = mapOf(
        "Mercurio" to doubleArrayOf(48.3313, 3.24587e-5, 7.0047, 5.00e-8, 29.1241, 1.01444e-5, 0.387098, 0.0, 0.205635, 5.59e-10, 168.6562, 4.0923344368),
        "Venus" to doubleArrayOf(76.6799, 2.46590e-5, 3.3946, 2.75e-8, 54.8910, 1.38374e-5, 0.723330, 0.0, 0.006773, -1.302e-9, 48.0052, 1.6021302244),
        "Marte" to doubleArrayOf(49.5574, 2.11081e-5, 1.8497, -1.78e-8, 286.5016, 2.92961e-5, 1.523688, 0.0, 0.093405, 2.516e-9, 18.6021, 0.5240207766),
        "Júpiter" to doubleArrayOf(100.4542, 2.76854e-5, 1.3030, -1.557e-7, 273.8777, 1.64505e-5, 5.20256, 0.0, 0.048498, 4.469e-9, 19.8950, 0.0830853001),
        "Saturno" to doubleArrayOf(113.6634, 2.38980e-5, 2.4886, -1.081e-7, 339.3939, 2.97661e-5, 9.55475, 0.0, 0.055546, -9.499e-9, 316.9670, 0.0334442282),
        "Urano" to doubleArrayOf(74.0005, 1.3978e-5, 0.7733, 1.9e-8, 96.6612, 3.0565e-5, 19.18171, -1.55e-8, 0.047318, 7.45e-9, 142.5905, 0.011725806),
        "Neptuno" to doubleArrayOf(131.7806, 3.0173e-5, 1.7700, -2.55e-7, 272.8461, -6.027e-6, 30.05826, 3.313e-8, 0.008606, 2.15e-9, 260.2471, 0.005995147)
    )

    private fun kepler(m: Double, e: Double): Double {
        var ea = m + e / D2R * sind(m) * (1.0 + e * cosd(m))
        for (i in 0 until 30) {
            val de = (ea - e / D2R * sind(ea) - m) / (1.0 - e * cosd(ea))
            ea -= de
            if (abs(de) < 1e-10) break
        }
        return ea
    }

    /** Devuelve [x, y, longitud, distancia] del Sol (geocéntrico, eclíptico). */
    private fun sunXY(d: Double): DoubleArray {
        val w = 282.9404 + 4.70935e-5 * d
        val e = 0.016709 - 1.151e-9 * d
        val m = rev(356.0470 + 0.9856002585 * d)
        val ea = kepler(m, e)
        val xv = cosd(ea) - e
        val yv = sqrt(1.0 - e * e) * sind(ea)
        val v = atan2d(yv, xv)
        val r = hypot(xv, yv)
        val lon = rev(v + w)
        return doubleArrayOf(r * cosd(lon), r * sind(lon), lon, r)
    }

    /** Eclíptica -> ecuatorial. Devuelve [RA en horas, Dec en grados]. */
    private fun eclToEq(x: Double, y: Double, z: Double, d: Double): DoubleArray {
        val ecl = 23.4393 - 3.563e-7 * d
        val ye = y * cosd(ecl) - z * sind(ecl)
        val ze = y * sind(ecl) + z * cosd(ecl)
        val raH = rev(atan2d(ye, x)) / 15.0
        val dec = atan2d(ze, hypot(x, ye))
        return doubleArrayOf(raH, dec)
    }

    private fun planetaRaDec(nombre: String, d: Double): DoubleArray {
        val el = ELEM[nombre] ?: throw IllegalArgumentException("Planeta desconocido: $nombre")
        val nodo = el[0] + el[1] * d
        val inc = el[2] + el[3] * d
        val w = el[4] + el[5] * d
        val a = el[6] + el[7] * d
        val e = el[8] + el[9] * d
        val m = rev(el[10] + el[11] * d)
        val ea = kepler(m, e)
        val xv = a * (cosd(ea) - e)
        val yv = a * sqrt(1.0 - e * e) * sind(ea)
        val v = atan2d(yv, xv)
        val r = hypot(xv, yv)
        var xh = r * (cosd(nodo) * cosd(v + w) - sind(nodo) * sind(v + w) * cosd(inc))
        var yh = r * (sind(nodo) * cosd(v + w) + cosd(nodo) * sind(v + w) * cosd(inc))
        var zh = r * sind(v + w) * sind(inc)
        var lonEcl = atan2d(yh, xh)
        var latEcl = atan2d(zh, hypot(xh, yh))

        val mj = rev(19.8950 + 0.0830853001 * d)
        val ms = rev(316.9670 + 0.0334442282 * d)
        val mu = rev(142.5905 + 0.011725806 * d)
        var dl = 0.0
        var db = 0.0
        when (nombre) {
            "Júpiter" -> {
                dl = (-0.332 * sind(2 * mj - 5 * ms - 67.6) - 0.056 * sind(2 * mj - 2 * ms + 21)
                    + 0.042 * sind(3 * mj - 5 * ms + 21) - 0.036 * sind(mj - 2 * ms)
                    + 0.022 * cosd(mj - ms) + 0.023 * sind(2 * mj - 3 * ms + 52)
                    - 0.016 * sind(mj - 5 * ms - 69))
            }
            "Saturno" -> {
                dl = (0.812 * sind(2 * mj - 5 * ms - 67.6) - 0.229 * cosd(2 * mj - 4 * ms - 2)
                    + 0.119 * sind(mj - 2 * ms - 3) + 0.046 * sind(2 * mj - 6 * ms - 69)
                    + 0.014 * sind(mj - 3 * ms + 32))
                db = -0.020 * cosd(2 * mj - 4 * ms - 2) + 0.018 * sind(2 * mj - 6 * ms - 49)
            }
            "Urano" -> {
                dl = (0.040 * sind(ms - mu + 6) + 0.035 * sind(ms - 2 * mu + 33)
                    - 0.015 * sind(mj - mu + 20))
            }
        }
        lonEcl += dl
        latEcl += db
        xh = r * cosd(lonEcl) * cosd(latEcl)
        yh = r * sind(lonEcl) * cosd(latEcl)
        zh = r * sind(latEcl)
        val sol = sunXY(d)
        return eclToEq(xh + sol[0], yh + sol[1], zh, d)
    }

    /** Luna topocéntrica (con paralaje). Devuelve [RA en horas, Dec en grados]. */
    private fun lunaRaDecTopo(d: Double, lat: Double, lstDeg: Double): DoubleArray {
        val nodo = rev(125.1228 - 0.0529538083 * d)
        val inc = 5.1454
        val w = rev(318.0634 + 0.1643573223 * d)
        val a = 60.2666
        val e = 0.054900
        val m = rev(115.3654 + 13.0649929509 * d)
        val ea = kepler(m, e)
        val xv = a * (cosd(ea) - e)
        val yv = a * sqrt(1.0 - e * e) * sind(ea)
        val v = atan2d(yv, xv)
        var r = hypot(xv, yv)
        val xh = r * (cosd(nodo) * cosd(v + w) - sind(nodo) * sind(v + w) * cosd(inc))
        val yh = r * (sind(nodo) * cosd(v + w) + cosd(nodo) * sind(v + w) * cosd(inc))
        val zh = r * sind(v + w) * sind(inc)
        var lon = atan2d(yh, xh)
        var la = atan2d(zh, hypot(xh, yh))

        val wSol = 282.9404 + 4.70935e-5 * d
        val mSol = rev(356.0470 + 0.9856002585 * d)
        val lSol = rev(mSol + wSol)
        val lLuna = rev(m + w + nodo)
        val dd = rev(lLuna - lSol)
        val f = rev(lLuna - nodo)
        lon += (-1.274 * sind(m - 2 * dd) + 0.658 * sind(2 * dd) - 0.186 * sind(mSol)
            - 0.059 * sind(2 * m - 2 * dd) - 0.057 * sind(m - 2 * dd + mSol)
            + 0.053 * sind(m + 2 * dd) + 0.046 * sind(2 * dd - mSol) + 0.041 * sind(m - mSol)
            - 0.035 * sind(dd) - 0.031 * sind(m + mSol) - 0.015 * sind(2 * f - 2 * dd)
            + 0.011 * sind(m - 4 * dd))
        la += (-0.173 * sind(f - 2 * dd) - 0.055 * sind(m - f - 2 * dd)
            - 0.046 * sind(m + f - 2 * dd) + 0.033 * sind(f + 2 * dd) + 0.017 * sind(2 * m + f))
        r += -0.58 * cosd(m - 2 * dd) - 0.46 * cosd(2 * dd)

        val x = r * cosd(lon) * cosd(la)
        val y = r * sind(lon) * cosd(la)
        val z = r * sind(la)
        val eq = eclToEq(x, y, z, d)
        val ra = eq[0] * 15.0
        val dec = eq[1]

        val mpar = asind(1.0 / r)
        val gclat = lat - 0.1924 * sind(2 * lat)
        val rho = 0.99833 + 0.00167 * cosd(2 * lat)
        val ha = rev(lstDeg - ra)
        val g = atan2d(tand(gclat), cosd(ha))
        val topRa = ra - mpar * rho * cosd(gclat) * sind(ha) / cosd(dec)
        val topDec = dec - mpar * rho * sind(gclat) * sind(g - dec) / sind(g)
        return doubleArrayOf(topRa / 15.0, topDec)
    }

    private fun gmstDeg(jd: Double): Double = rev(280.46061837 + 360.98564736629 * (jd - 2451545.0))

    /** Precesión de J2000 a la fecha (Meeus, cap. 21). */
    private fun precesionJ2000(raH: Double, dec: Double, jd: Double): DoubleArray {
        val t = (jd - 2451545.0) / 36525.0
        val zeta = (2306.2181 * t + 0.30188 * t * t + 0.017998 * t * t * t) / 3600.0
        val z = (2306.2181 * t + 1.09468 * t * t + 0.018203 * t * t * t) / 3600.0
        val theta = (2004.3109 * t - 0.42665 * t * t - 0.041833 * t * t * t) / 3600.0
        val ra = raH * 15.0
        val aa = cosd(dec) * sind(ra + zeta)
        val bb = cosd(theta) * cosd(dec) * cosd(ra + zeta) - sind(theta) * sind(dec)
        val cc = sind(theta) * cosd(dec) * cosd(ra + zeta) + cosd(theta) * sind(dec)
        val ra2 = rev(atan2d(aa, bb) + z)
        val dec2 = asind(max(-1.0, min(1.0, cc)))
        return doubleArrayOf(ra2 / 15.0, dec2)
    }

    /** Día juliano a partir de milisegundos desde 1970 (UTC). */
    fun diaJuliano(millis: Long): Double = millis / 86400000.0 + 2440587.5

    /**
     * Altitud y azimut de [obj] en el instante [millis] (UTC, ms desde 1970), para un
     * observador en [lat] grados Norte y [lonEste] grados Este (Panamá: negativo).
     * Sin refracción atmosférica.
     */
    fun posicion(obj: Objeto, millis: Long, lat: Double, lonEste: Double): AltAz {
        val jd = diaJuliano(millis)
        val d = jd - 2451543.5
        val lst = rev(gmstDeg(jd) + lonEste)
        val raH: Double
        val dec: Double
        if (obj.nombre == "Luna") {
            val p = lunaRaDecTopo(d, lat, lst)
            raH = p[0]
            dec = p[1]
        } else if (obj.fijo) {
            val p = precesionJ2000(obj.raHoras, obj.decGrados, jd)
            raH = p[0]
            dec = p[1]
        } else {
            val p = planetaRaDec(obj.nombre, d)
            raH = p[0]
            dec = p[1]
        }
        val ha = rev(lst - raH * 15.0)
        val alt = asind(sind(lat) * sind(dec) + cosd(lat) * cosd(dec) * cosd(ha))
        val az = rev(atan2d(-cosd(dec) * sind(ha), sind(dec) * cosd(lat) - cosd(dec) * sind(lat) * cosd(ha)))
        return AltAz(alt, az)
    }

    fun porNombre(nombre: String): Objeto =
        CATALOGO.firstOrNull { it.nombre == nombre } ?: throw IllegalArgumentException("Objeto desconocido: $nombre")

    fun punto(az: Double): String {
        val puntos = arrayOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
        return puntos[(floor((az + 22.5) / 45.0).toInt() % 8 + 8) % 8]
    }
}
