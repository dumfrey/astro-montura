package com.astro.montura

import android.net.Network
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign

const val IP_POR_DEFECTO = "192.168.4.1"
const val PUERTO = 11880
const val TIMEOUT_MS = 2000

const val V_LENTA_MAX = 0.5   // °/s, modo lento
const val V_MAX = 3.0         // °/s, tope absoluto

class ErrorMontura(mensaje: String) : Exception(mensaje)

fun aHex24(valor: Int): String {
    val v = valor and 0xFFFFFF
    return String.format(Locale.US, "%02X%02X%02X", v and 0xFF, (v shr 8) and 0xFF, (v shr 16) and 0xFF)
}

fun deHex24(texto: String): Int {
    if (texto.length < 6) throw ErrorMontura("Respuesta inesperada: '$texto'")
    return (texto.substring(4, 6) + texto.substring(2, 4) + texto.substring(0, 2)).toInt(16)
}

/** Lleva un ángulo al rango [-180, 180). */
fun envolver(grados: Double): Double {
    val r = (grados + 180.0) % 360.0
    return (if (r < 0) r + 360.0 else r) - 180.0
}

/**
 * Control de la montura Sky-Watcher AZ-GTi por WiFi (UDP, protocolo Skywatcher).
 * Eje 1 = azimut, eje 2 = altitud. Port de montura.py.
 */
class Montura(private val log: (String) -> Unit) {
    private class EstadoEje {
        var mov = false
        var digito: Int? = null
        var modo: String? = null
        var periodo: Int? = null
        fun limpiar() {
            mov = false; digito = null; modo = null; periodo = null
        }
    }

    private val lock = ReentrantLock()
    private var socket: DatagramSocket? = null
    private var destino: InetAddress? = null
    private val cpr = intArrayOf(0, 0, 0)
    private val tf = intArrayOf(0, 0, 0)
    private val ratio = intArrayOf(16, 16, 16)
    val signo = intArrayOf(1, 1, 1)
    private val off = doubleArrayOf(0.0, 0.0, 0.0)
    private val dirPos = intArrayOf(0, 0, 0)
    private val estado = arrayOf(EstadoEje(), EstadoEje(), EstadoEje())
    private val pararFlag = AtomicBoolean(false)

    @Volatile var conectado = false
        private set
    @Volatile var calibrado = false

    // ------------------------------------------------------- comunicación
    private fun cmd(texto: String): String {
        lock.withLock {
            val s = socket ?: throw ErrorMontura("No hay conexión con la montura.")
            val dest = destino ?: throw ErrorMontura("No hay conexión con la montura.")
            val datos = (":$texto\r").toByteArray(Charsets.US_ASCII)
            s.send(DatagramPacket(datos, datos.size, dest, PUERTO))
            val buf = ByteArray(1024)
            val paquete = DatagramPacket(buf, buf.size)
            s.receive(paquete)
            val resp = String(paquete.data, 0, paquete.length, Charsets.US_ASCII).trim()
            if (!resp.startsWith("=")) {
                throw ErrorMontura("La montura respondió con error a ':$texto' -> '$resp'")
            }
            return resp.substring(1)
        }
    }

    /** Conecta con la montura. [red] es la red WiFi a la que se ata el socket (puede ser null). */
    fun conectar(ip: String, red: Network?) {
        lock.withLock {
            cerrar()
            val s = DatagramSocket()
            try {
                red?.bindSocket(s)
                s.soTimeout = TIMEOUT_MS
                destino = InetAddress.getByName(ip)
                socket = s
                for (e in 1..2) {
                    cmd("e$e")
                    cpr[e] = deHex24(cmd("a$e"))
                    tf[e] = deHex24(cmd("b$e"))
                    ratio[e] = try {
                        val r = cmd("g$e")
                        val rat = if (r.length == 6) deHex24(r) else r.toInt(16)
                        if (rat in 1..255) rat else 16
                    } catch (ex: SocketTimeoutException) {
                        throw ex
                    } catch (ex: Exception) {
                        16
                    }
                    cmd("F$e")
                }
            } catch (ex: SocketTimeoutException) {
                cerrar()
                try { s.close() } catch (_: Exception) {}
                throw ErrorMontura(
                    "Sin respuesta de la montura. Revisa que el celular esté en el WiFi " +
                        "'SynScan_xxxx', que la montura esté encendida y que la app SynScan esté cerrada."
                )
            } catch (ex: Exception) {
                cerrar()
                try { s.close() } catch (_: Exception) {}
                if (ex is ErrorMontura) throw ex
                throw ErrorMontura("No se pudo conectar: ${ex.message}")
            }
            conectado = true
            calibrado = false
            for (e in 1..2) estado[e].limpiar()
            pararFlag.set(false)
        }
        detectarSentidos()
    }

    fun cerrar() {
        lock.withLock {
            conectado = false
            try { socket?.close() } catch (_: Exception) {}
            socket = null
        }
    }

    fun desconectar() {
        try { parar() } finally { cerrar() }
    }

    /** Mueve cada eje ~0.08° para saber qué dígito de sentido hace crecer la posición. */
    private fun detectarSentidos() {
        for (e in 1..2) {
            try {
                val antes = rawEje(e)
                cmd("K$e")
                Thread.sleep(200)
                cmd("G${e}10")
                val periodo = max((tf[e] / (cpr[e] * 0.2 / 360.0)).toInt(), 1)
                cmd("I$e${aHex24(periodo)}")
                cmd("J$e")
                Thread.sleep(400)
                cmd("K$e")
                Thread.sleep(600)
                val despues = rawEje(e)
                if (abs(despues - antes) < 0.005) {
                    dirPos[e] = 0
                    log("Aviso: el eje $e no mostró movimiento en la prueba de sentido.")
                } else {
                    dirPos[e] = if (despues > antes) 0 else 1
                }
            } catch (ex: Exception) {
                log("Aviso: no se pudo detectar el sentido del eje $e: ${ex.message}")
            }
        }
        log("Sentidos detectados: eje1=${dirPos[1]}, eje2=${dirPos[2]}")
    }

    // ----------------------------------------------------------- posición
    private fun rawEje(eje: Int): Double {
        val pasos = deHex24(cmd("j$eje")) - 0x800000
        return pasos.toDouble() / cpr[eje] * 360.0
    }

    fun angulo(eje: Int): Double = signo[eje] * (rawEje(eje) - off[eje])

    fun azimutAltitud(): Pair<Double, Double> {
        val az = angulo(1)
        return Pair(((az % 360.0) + 360.0) % 360.0, angulo(2))
    }

    fun calibrarEn(azimut: Double, altitud: Double) {
        lock.withLock {
            off[1] = rawEje(1) - signo[1] * azimut
            off[2] = rawEje(2) - signo[2] * altitud
            calibrado = true
        }
    }

    // ---------------------------------------------------------- movimiento
    /** Velocidad del eje en °/s (coordenadas de la app). 0 = parar. */
    fun setVel(eje: Int, v: Double) {
        lock.withLock {
            if (!conectado) return
            val st = estado[eje]
            val vm = max(min(v * signo[eje], V_MAX), -V_MAX)
            if (abs(vm) < 0.0005) {
                if (st.mov) {
                    cmd("K$eje")
                    Thread.sleep(300)
                    st.limpiar()
                }
                return
            }
            val digito = if (vm > 0) dirPos[eje] else 1 - dirPos[eje]
            val modo = if (abs(vm) > V_LENTA_MAX + 1e-9) "3" else "1"
            if (st.mov && (st.digito != digito || st.modo != modo)) {
                cmd("K$eje")
                Thread.sleep(500)
                st.limpiar()
            }
            val pasosS = cpr[eje] * abs(vm) / 360.0
            var base = tf[eje] / pasosS
            if (modo == "3") base *= ratio[eje]
            val periodo = max(base.toInt(), 1)
            if (!st.mov) cmd("G$eje$modo$digito")
            if (periodo != st.periodo) cmd("I$eje${aHex24(periodo)}")
            if (!st.mov) cmd("J$eje")
            st.mov = true
            st.digito = digito
            st.modo = modo
            st.periodo = periodo
        }
    }

    /** Parada de emergencia: detiene ambos motores y cancela cualquier operación. */
    fun parar() {
        pararFlag.set(true)
        if (!conectado) return
        for (e in 1..2) {
            for (orden in arrayOf("K", "L")) {
                try { cmd("$orden$e") } catch (_: Exception) {}
            }
            estado[e].limpiar()
        }
    }

    private fun pararEjes() {
        for (e in 1..2) {
            try { setVel(e, 0.0) } catch (_: Exception) {}
        }
    }

    /** Lazo cerrado hasta (azimut, altitud). true si llegó, false si fue detenida. */
    fun irA(azimut: Double, altitud: Double, vmaxIn: Double = V_LENTA_MAX): Boolean {
        if (!calibrado) throw ErrorMontura("Primero hay que calibrar la montura.")
        if (altitud < 0.0 || altitud > 88.0) {
            throw ErrorMontura(String.format(Locale.US, "Altitud %.1f° fuera del rango seguro (0 a 88°).", altitud))
        }
        val vmax = min(vmaxIn, V_MAX)
        pararFlag.set(false)
        val azIni = angulo(1)
        val altIni = angulo(2)
        val dest = doubleArrayOf(0.0, azIni + envolver(azimut - azIni), altitud)
        val dist = max(abs(dest[1] - azIni), abs(dest[2] - altIni))
        val limite = System.currentTimeMillis() + ((dist / max(vmax, 0.05) * 2.0 + 20.0) * 1000).toLong()
        try {
            while (!pararFlag.get()) {
                var listo = true
                for (e in 1..2) {
                    val err = dest[e] - angulo(e)
                    if (abs(err) < 0.05) {
                        setVel(e, 0.0)
                        continue
                    }
                    listo = false
                    var v = max(min(err / 1.5, vmax), -vmax)
                    if (abs(v) < 0.03) v = 0.03 * sign(err)
                    setVel(e, v)
                }
                if (listo) return true
                if (System.currentTimeMillis() > limite) {
                    throw ErrorMontura("Tiempo agotado antes de llegar; motores detenidos.")
                }
                Thread.sleep(50)
            }
            return false
        } finally {
            pararEjes()
        }
    }

    /**
     * Sigue un objeto. [funcionAzAlt](dt) da (azimut, altitud) del objeto dentro de dt segundos.
     * Se corrige una vez por segundo. [detener] se consulta en cada ciclo.
     */
    fun seguir(funcionAzAlt: (Double) -> Pair<Double, Double>, detener: AtomicBoolean, vmax: Double = V_LENTA_MAX) {
        if (!calibrado) throw ErrorMontura("Primero hay que calibrar la montura.")
        pararFlag.set(false)
        try {
            while (!detener.get() && !pararFlag.get()) {
                val t0 = System.currentTimeMillis()
                val (az, alt) = funcionAzAlt(0.0)
                val (az2, alt2) = funcionAzAlt(1.0)
                if (alt < 0.0 || alt > 88.0) {
                    throw ErrorMontura("El objeto salió del rango de altitud; seguimiento detenido.")
                }
                val eAz = envolver(az - angulo(1))
                val eAlt = alt - angulo(2)
                if (abs(eAz) > 5.0 || abs(eAlt) > 5.0) {
                    throw ErrorMontura("Se perdió el objeto (más de 5° de error). Presiona Apuntar otra vez.")
                }
                val vAz = envolver(az2 - az) + eAz / 3.0
                val vAlt = (alt2 - alt) + eAlt / 3.0
                setVel(1, max(min(vAz, vmax), -vmax))
                setVel(2, max(min(vAlt, vmax), -vmax))
                val resto = 1000 - (System.currentTimeMillis() - t0)
                if (resto > 0) Thread.sleep(resto)
            }
        } finally {
            pararEjes()
        }
    }
}
