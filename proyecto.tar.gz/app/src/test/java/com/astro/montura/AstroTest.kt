package com.astro.montura

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.PI
import org.junit.Assert.assertTrue
import org.junit.Test

class AstroTest {
    private val lat = 8.99
    private val lon = -79.56

    private data class Caso(val nombre: String, val millis: Long, val alt: Double, val az: Double)

    private fun difAz(a: Double, b: Double): Double = ((a - b + 540.0) % 360.0) - 180.0

    /** Valores calculados con la versión en Python, que a su vez coincide con JPL Horizons. */
    private val casos = listOf(
        Caso("Saturno", 1791597600000L, 47.7091, 97.2823),
        Caso("Saturno", 1805095800000L, -73.0849, 41.6503),
        Caso("Luna", 1797739200000L, 50.7284, 286.8947),
        Caso("Luna", 1811818800000L, -63.1826, 37.0635),
        Caso("Júpiter", 1799557200000L, 47.2361, 79.2967),
        Caso("Marte", 1797739200000L, 0.4345, 78.6133),
        Caso("Venus", 1805095800000L, -25.0472, 103.4436),
        Caso("M42 Nebulosa de Orión", 1797739200000L, 69.2975, 133.3861),
        Caso("Sirio", 1791622800000L, 52.7961, 133.6961),
        Caso("Vega", 1805095800000L, 18.1887, 51.9822),
        Caso("M31 Galaxia de Andrómeda", 1791597600000L, 40.8857, 41.5042),
        Caso("Antares", 1811818800000L, 42.2276, 138.8905),
        Caso("Omega Centauri (NGC 5139)", 1811818800000L, 32.2786, 190.0903)
    )

    @Test
    fun coincideConReferenciaPython() {
        for (c in casos) {
            val p = Astro.posicion(Astro.porNombre(c.nombre), c.millis, lat, lon)
            assertTrue("${c.nombre}: altitud ${p.altitud} vs ${c.alt}", abs(p.altitud - c.alt) < 0.01)
            assertTrue("${c.nombre}: azimut ${p.azimut} vs ${c.az}", abs(difAz(p.azimut, c.az)) < 0.01)
        }
    }

    /** Valores de JPL Horizons (Saturno, 2026-10-10 02:00 y 03:00 UT; Luna 2026-12-20 04:00 UT). */
    @Test
    fun coincideConNasaHorizons() {
        val saturno = Astro.porNombre("Saturno")
        val p1 = Astro.posicion(saturno, 1791597600000L, lat, lon)
        assertTrue("Saturno alt ${p1.altitud}", abs(p1.altitud - 47.694) < 0.1)
        assertTrue("Saturno az ${p1.azimut}", abs(difAz(p1.azimut, 97.268)) < 0.1)
        val p2 = Astro.posicion(saturno, 1791601200000L, lat, lon)
        assertTrue("Saturno alt ${p2.altitud}", abs(p2.altitud - 62.320) < 0.1)
        assertTrue("Saturno az ${p2.azimut}", abs(difAz(p2.azimut, 103.479)) < 0.1)
        val luna = Astro.posicion(Astro.porNombre("Luna"), 1797739200000L, lat, lon)
        assertTrue("Luna alt ${luna.altitud}", abs(luna.altitud - 50.727) < 0.1)
        assertTrue("Luna az ${luna.azimut}", abs(difAz(luna.azimut, 286.927)) < 0.1)
    }

    @Test
    fun catalogoTieneTodosLosObjetos() {
        assertTrue(Astro.CATALOGO.size == 28)
        assertTrue(Astro.punto(0.0) == "N" && Astro.punto(97.0) == "E" && Astro.punto(359.0) == "N")
        assertTrue(cos(PI) < 0)
    }
}
